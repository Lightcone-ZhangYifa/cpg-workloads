include(Platform/CYGWIN-GNU)
